import socketserver
import os
import json


class MyTCPHandler(socketserver.BaseRequestHandler):
    """
    The request handler class for our server.

    It is instantiated once per connection to the server, and must
    override the handle() method to implement communication to the
    client.
    b'000':文件不存在
    b'001':目录不是空
    b'100':用户名不存在
    b'101':密码错误
    b’111‘:登录成功
    b'200':目录不可切换
    b‘202’:非法目录名称
    b'222':文件夹已存在
    b’400‘:内存不足
    """

    access_addr = os.path.dirname(os.path.abspath(__file__))  # server\core
    DATABASE = {
        "volume": 5 * 1024 * 1024 * 1024,
        "used": 0
    }
    user_json = ''
    connect_num = 0

    def handle(self):
        MyTCPHandler.connect_num += 1
        print("%d Working..."% MyTCPHandler.connect_num)
        try:
            self.validate_logon()
            print(self.client_address[0])
            while True:
                msg = json.loads(self.request.recv(1024).decode())
                # self.access_addr = os.path.join(self.access_addr,'user_files',self.DATABASE["user name"])
                # server\user_files\
                cmd_str = 'cmd_' + msg["action"]
                if hasattr(self, cmd_str):
                    func = getattr(self, cmd_str)
                    func(msg)
        except ConnectionResetError as e:
            MyTCPHandler.connect_num -= 1
            print("%s客户端，断开连接"% self.client_address[0])

    # 登录验证
    def validate_logon(self):
        #  self.access_addr = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # server

        while True:
            user_messages = json.loads(self.request.recv(1024).decode())
            user_name = user_messages["user name"]
            user_password = user_messages["user password"]
            register = user_messages["register"]
            user_dir = os.path.join(self.access_addr, 'db')
            # 用户认证文件相对地址
            if not os.path.isdir(user_dir):
                os.mkdir(user_dir)  # 创建目录
            user_dir = os.path.join(user_dir, '%s.json' % user_name)
            # 用户认证文件相对地址
            self.user_json = user_dir  # 用户认证文件保留
            if register == 'Y':
                self.DATABASE["user name"] = user_name
                self.DATABASE["user password"] = user_password
                self.up_json()
                reply = b"%.2fGB/%.2fGB" % (self.DATABASE["used"] / (1024 * 1024 * 1024),\
                                            self.DATABASE["volume"] / (1024 * 1024 * 1024))
                self.request.send(reply)
                print("登录成功欢迎使用！")
                break
            else:
                if os.path.isfile(user_dir):  # 判断该用户是否存在
                    f = open(user_dir, "r")
                    self.DATABASE = json.loads(f.read())
                    if user_password == self.DATABASE["user password"]:
                        reply = b"%.2fGB/%.2fGB" % (self.DATABASE["used"] / (1024 * 1024 * 1024),\
                                                    self.DATABASE["volume"] / (1024 * 1024 * 1024))
                        self.request.send(reply)
                        print("登录成功欢迎使用！")
                        break
                    else:
                        self.request.send(b'101')  # b'101':密码错误
                    f.close()
                else:
                    self.request.send(b'100')  # b'100':用户名不存在

            continue  # 退出当前循环，进入下次验证

        self.access_addr = os.path.join(self.access_addr, 'user_files')
        # 用户文件存放目录
        if not os.path.isdir(self.access_addr):
            os.mkdir(self.access_addr)  #创建目录

        self.access_addr = os.path.join(self.access_addr, user_name)
        # 用户文件存放目录
        if not os.path.isdir(self.access_addr):
            os.mkdir(self.access_addr)  #创建目录

    # 用户认证文件更新
    def up_json(self):
        with open(self.user_json,'w') as f:
            f_data = json.dumps(self.DATABASE)  # 配置用户信息文件
            f.write(f_data)

    # 文件上传
    def cmd_put(self, msg_doc):
        file_name, file_size = msg_doc["file name"], msg_doc["file size"]
        print("准备上传文件",file_name)
        if file_size > (self.DATABASE["volume"] - self.DATABASE["used"]):
            self.request.send(b"400")
        else:
            self.request.send(b'sever ready recv')
            file_dir = os.path.join(self.access_addr, file_name)
            if msg_doc["overridden"]:
                old_size = 0
                if os.path.isfile(file_dir):
                    old_size = os.stat(file_dir).st_size
                print("正在%s文件夹中上传文件%s"% (self.access_addr, file_name))
                f = open(file_dir, "wb")
                new_size = 0
                while new_size < file_size:
                    data = self.request.recv(1024)
                    new_size += len(data)
                    f.write(data)
                else:
                    print("%s 上传成功" % file_name, file_size, new_size)
                    self.DATABASE["used"] += new_size - old_size
                    f.close()
                    self.up_json()

            elif os.path.isfile(file_dir):
                pass

    # 文件下载
    def cmd_get(self, msg_doc):
        file_name = msg_doc["file name"]
        file_dir = os.path.join(self.access_addr,file_name)
        if os.path.isfile(file_dir):
            file_size = os.stat(file_dir).st_size
            self.request.send(str(file_size).encode("utf-8"))
            self.request.recv(1024)
            f = open(file_dir,"rb")
            f.seek(msg_doc["old size"])  # 文件光标跳至之前位置
            for line in f:
                self.request.send(line)
            f.close()
        else:
            self.request.send(b"000")

    # 删除文件或目录
    def cmd_del(self, msg_doc):
        file_name = msg_doc["file name"]
        file_dir = os.path.join(self.access_addr,file_name)
        if os.path.isfile(file_dir):
            file_size = os.stat(file_dir).st_size
            os.remove(file_dir)
            self.DATABASE["used"] -= file_size
            self.cmd_dir()
            self.up_json()
        elif os.path.isdir(file_dir):
            try:
                os.rmdir(file_dir)
                self.cmd_dir()
            except OSError as e:
                self.request.send(b"001")
        else:
            self.request.send(b"000")

    # 查看容量
    def cmd_sp(self, msg_doc):
        reply = b"%.2fGB/%.2fGB" % (self.DATABASE["used"] / (1024 * 1024 * 1024), \
                                    self.DATABASE["volume"] / (1024 * 1024 * 1024))
        self.request.send(reply)

    # 查看当前目录和目录下的内容
    def cmd_dir(self, *args):
        dir_message = list(os.walk(self.access_addr).__next__())
        father_dir = os.path.dirname(os.path.abspath(__file__))
        father_dir = os.path.join(father_dir, 'user_files')
        # 执行软件的父目录
        dir_message[0] = dir_message[0][len(father_dir):]
        self.request.send(json.dumps(dir_message).encode("utf-8"))

    # 切换目录
    def cmd_cd(self, msg_doc):
        cd_path = msg_doc["dir"]
        if cd_path == "..":
            father_dir = os.path.dirname(os.path.abspath(__file__))
            father_dir = os.path.join(father_dir, 'user_files')
            # print(father_dir)
            # 执行软件的父目录
            if os.path.dirname(self.access_addr) != father_dir:
                self.access_addr = os.path.dirname(self.access_addr)
                self.cmd_dir()
            else:
                self.request.send(b'200')
        else:
            new_dir = os.path.join(self.access_addr,cd_path)
            if os.path.isdir(new_dir):
                self.access_addr = new_dir
                self.cmd_dir()
            else:
                self.request.send(b'200')

    # 新建目录
    def cmd_mkdir(self, msg_doc):
        new_path = msg_doc["dir"]
        illegal_char = '\/:*?"<>|'
        for c in illegal_char:
            if c in new_path:  # 判断非法字符是否在文件夹名称中
                self.request.send(b'202')
                return 0
        new_path = os.path.join(self.access_addr,new_path)
        if not os.path.isdir(new_path):
            os.mkdir(new_path)
            self.cmd_dir()
        else:
            self.request.send(b'222')




HOST, PORT = "0.0.0.0", 9999
print("Waiting...")
# Create the server, binding to localhost on port 9999
server = socketserver.ThreadingTCPServer((HOST, PORT), MyTCPHandler)

# Activate the server; this will keep running until you
# interrupt the program with Ctrl-C
server.serve_forever()