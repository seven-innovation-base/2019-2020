import socket
import os
import json
import sys


class FTPClient(object):
    def __init__(self):
        self.client = socket.socket()

    def cmd_help(self, *args):
        msg = '''
            dir             #查看当前目录和目录下的内容
            sp              #查看容量
            cd ..\\..       #切换目录
            mkdir dirname   #新建目录
            get filename    #下载文件
            put filename    #上传文件
            del name        #删除文件或目录
        '''
        print(msg)

    def connect(self, ip, part):
        self.client.connect((ip, part))

    # 登录
    def authenticate(self):
        while True:
            sign = input("是否注册新账户（Y/N）>>:").strip()
            user_name = input("请输入用户名 >>:").strip()
            user_password = input("请输入密码 >>:").strip()
            user_messages = {
                "register": sign,
                "user name": user_name,
                "user password": user_password
            }
            self.client.send(json.dumps(user_messages).encode("utf-8"))
            login = self.client.recv(1024)
            if login == b'100':
                print("error:100 用户名不存在！")
            elif login == b'101':
                print("error:101 密码错误！")
            elif len(login):
                print("登录成功",login.decode())
                break  # 登录成功退出程序
            continue  # 登录失败

    # 入口函数
    def interative(self):
        self.authenticate()
        while True:
            cmd = input("请输入操作指令>>:").strip()
            if not len(cmd): continue
            cmd_str = 'cmd_' + cmd.split()[0]
            if hasattr(self, cmd_str):
                func = getattr(self, cmd_str)
                func(cmd)
            else:
                print("错误指令！")
                self.cmd_help()

    # 文件上传
    def cmd_put(self, *args):
        cmd_split = args[0].split()
        if len(cmd_split) == 2:
            file_name = cmd_split[1]
            if os.path.isfile(file_name):
                file_size = os.stat(file_name).st_size
                msg_doc = {
                    "action": "put",
                    "file name": file_name,
                    "file size": file_size,
                    "overridden": True
                }
                self.client.send(json.dumps(msg_doc).encode("utf-8"))
                server_reply = self.client.recv(1024)
                if server_reply == b'400':
                    print("error:400 内存不足！")
                    return 0
                f = open(file_name, "rb")
                new_file = 0
                i = 0
                for line in f:
                    self.client.send(line)
                    new_file += len(line)
                    if (new_file*100)//file_size == i:
                        self.print_progress(i)
                        i += 1
                f.close()
                print("\n上传成功！")
            else:
                print("没有找到这个文件")
        else:
            print("错误指令！")
            self.cmd_help()

    # 文件下载
    def cmd_get(self, *args):
        cmd_split = args[0].split()
        if len(cmd_split) == 2:
            file_name_old = cmd_split[1]
            file_name = input("保存文件名称>>:") or file_name_old
            old_size = 0
            if os.path.isfile(file_name):
                old_size = os.stat(file_name).st_size
            msg_doc = {
                "action": "get",
                "file name": file_name_old,
                "old size":old_size
            }
            self.client.send(json.dumps(msg_doc).encode("utf-8"))
            file_size = self.client.recv(1024)
            if file_size == b"000":
                print("error:000 文件不存在！")
                return 0
            file_size = int(file_size.decode())
            self.client.send(b"ready to recv the file")
            new_size = old_size
            f = open(file_name, 'ab')
            i = (new_size*100)//file_size
            while new_size < file_size:
                data = self.client.recv(1024)
                new_size += len(data)
                f.write(data)
                if (new_size*100)//file_size == i:
                    self.print_progress(i)
                    i += 1
            else:
                print("\n%s recv done" % file_name, file_size, new_size)
                f.close()
        else:
            print("错误指令！")
            self.cmd_help()

    # 删除文件或目录
    def cmd_del(self, *args):
        cmd_split = args[0].split()
        if len(cmd_split) == 2:
            file_name = cmd_split[1]
            msg_doc = {
                "action": "del",
                "file name": file_name
            }
            self.client.send(json.dumps(msg_doc).encode("utf-8"))
            self.print_dir()
        else:
            print("错误指令！")
            self.cmd_help()

    # 查看容量
    def cmd_sp(self, *args):
        cmd_split = args[0].split()
        if len(cmd_split) == 1:
            msg_doc = {
                "action": "sp"
            }
            self.client.send(json.dumps(msg_doc).encode("utf-8"))
            space = self.client.recv(1024).decode()
            print("空间容量：",space)
        else:
            print("错误指令！")
            self.cmd_help()

    # 打印进度条
    def print_progress(self,i):
        k = i + 1
        str = '>' * (i // 2) + ' ' * ((100 - k) // 2)
        sys.stdout.write('\r' + str + '[%s%%]' % i)
        sys.stdout.flush()

    # 打印目录下的文件
    def print_dir(self):
        server_reply = self.client.recv(1024)
        if server_reply == b'200':
            print("error:200 目录不可切换！")
            return 0
        elif server_reply == b'202':
            print('error:202 非法目录名称，不能包含 \/:*?"<>| 字符！')
            return 0
        elif server_reply == b'222':
            print("error:222 文件夹已存在！")
            return 0
        elif server_reply == b'000':
            print("error:000 文件不存在！")
            return 0
        elif server_reply == b'001':
            print("error:001 目录不为空！")
            return 0

        server_reply = json.loads(server_reply.decode())
        # server_reply 内存放服务器返回的目录名和文件名
        print("\n%s目录下：" % server_reply[0])
        for i in server_reply[1]:
            print(">>", i)
        for i in server_reply[2]:
            print(i)
        print()

    # 查看当前目录和目录下的内容
    def cmd_dir(self, *args):
        cmd_split = args[0].split()
        if len(cmd_split) == 1:
            msg_doc = {
                "action": "dir"
            }
            self.client.send(json.dumps(msg_doc).encode("utf-8"))
            self.print_dir()
        else:
            print("错误指令！")
            self.cmd_help()

    # 切换目录
    def cmd_cd(self, *args):
        cmd_split = args[0].split()
        if len(cmd_split) == 2:
            msg_doc = {
                "action": cmd_split[0],
                "dir":cmd_split[1]
            }
            self.client.send(json.dumps(msg_doc).encode("utf-8"))
            self.print_dir()
        else:
            print("错误指令！")
            self.cmd_help()

    # 新建文件夹
    def cmd_mkdir(self, *args):
        self.cmd_cd(args[0])


client = FTPClient()
ip4 = input("请输入服务端ip地址>>:").strip()
client.connect(ip4, 9999)
client.interative()
